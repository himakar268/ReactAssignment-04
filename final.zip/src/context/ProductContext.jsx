import { createContext, useContext, useState, useEffect } from 'react';
import { fetchProducts, addProduct as apiAddProduct, fetchProduct as apiFetchProduct } from '../utils/api';

// 1. Create context (export both Provider and Context)
export const ProductContext = createContext();

// 2. Create Provider component
export const ProductProvider = ({ children }) => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  const getProducts = async () => {
    try {
      const data = await fetchProducts();
      setProducts(data);
    } catch (error) {
      console.error('Failed to fetch products:', error);
    } finally {
      setLoading(false);
    }
  };

  const addProduct = async (product) => {
    try {
      const newProduct = await apiAddProduct(product);
      setProducts([...products, newProduct]);
      return newProduct;
    } catch (error) {
      console.error('Failed to add product:', error);
      throw error;
    }
  };

  const getProductById = async (id) => {
    try {
      return await apiFetchProduct(id);
    } catch (error) {
      console.error('Failed to fetch product:', error);
      throw error;
    }
  };

  useEffect(() => { getProducts(); }, []);

  return (
    <ProductContext.Provider 
      value={{ products, loading, addProduct, getProducts, getProductById }}
    >
      {children}
    </ProductContext.Provider>
  );
};

// 3. Create custom hook
export const useProducts = () => {
  const context = useContext(ProductContext);
  if (!context) {
    throw new Error('useProducts must be used within ProductProvider');
  }
  return context;
};