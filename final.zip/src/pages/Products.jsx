import { useNavigate } from 'react-router-dom';
import { useProducts } from '../context/ProductContext.jsx';

export default function Products() {
  const { products, loading } = useProducts();
  const navigate = useNavigate();

  if (loading) return <div>Loading products...</div>;

  return (
    <div>
      <h1>Product List</h1>
      
      
      <table border="1">
        <thead>
          <tr>
            <th>Product Name</th>
            <th>Quantity</th>
            <th>Price</th>
          </tr>
        </thead>
        <tbody>
          {products.map(product => (
            <tr key={product.id}>
              <td>{product.ProductName}</td>
              <td>{product.Quantity}</td>
              <td>Rs.{product.Price.toFixed(2)}</td>
             
            </tr>
          ))}
        </tbody>
      </table>
      <div style={{ marginTop: '10px' }}>
      <button onClick={() => navigate('/products/add')}>Add New Product</button>
      </div>
    </div>
  );
}