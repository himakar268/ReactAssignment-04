import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import { useNavigate } from 'react-router-dom';
import { useProducts } from '../context/ProductContext.jsx';
import { nanoid } from 'nanoid';

const validationSchema = Yup.object().shape({
  ProductName: Yup.string()
    .required('Product name is required')
    .min(3, 'Must be at least 3 characters'),
  Quantity: Yup.number()
    .required('Quantity is required')
    .min(1, 'Must be at least 1')
    .integer('Must be an integer'),
  Price: Yup.number()
    .required('Price is required')
    .min(0.01, 'Must be greater than 0')
});

export default function AddProduct() {
  const { addProduct } = useProducts();
  const navigate = useNavigate();

  return (
    <div>
      <h1>Add Product</h1>
      <Formik
        initialValues={{ ProductName: '', Quantity: '', Price: '' }}
        validationSchema={validationSchema}
        onSubmit={async (values, { setSubmitting }) => {
          try {
            const product = {
              ...values,
              id: nanoid(10)
            };
            await addProduct(product);
            navigate('/products');
          } catch (error) {
            console.error('Error:', error);
          } finally {
            setSubmitting(false);
          }
        }}
      >
        {({ isSubmitting }) => (
          <Form>
            <div>
              <label>Product Name</label>
              <Field type="text" name="ProductName" />
              <ErrorMessage name="ProductName" component="div" />
            </div>

            <div>
              <label>Quantity</label>
              <Field type="number" name="Quantity" />
              <ErrorMessage name="Quantity" component="div" />
            </div>

            <div>
              <label>Price</label>
              <Field type="number" name="Price" step="0.01" />
              <ErrorMessage name="Price" component="div" />
            </div>

            <button type="submit" disabled={isSubmitting}>
              {isSubmitting ? 'Submitting...' : 'Add Product'}
            </button>
          </Form>
        )}
      </Formik>
    </div>
  );
}