import { useParams } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { useProducts } from '../context/ProductContext.jsx';

export default function ProductDetail() {
  const { id } = useParams();
  const { getProductById } = useProducts();
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadProduct = async () => {
      try {
        const data = await getProductById(id);
        setProduct(data);
      } catch (error) {
        console.error('Error:', error);
      } finally {
        setLoading(false);
      }
    };
    loadProduct();
  }, [id, getProductById]);

  if (loading) return <div>Loading...</div>;
  if (!product) return <div>Product not found</div>;

  return (
    <div>
      <h1>Product Details</h1>
      <p><strong>ID:</strong> {product.id}</p>
      <p><strong>Name:</strong> {product.ProductName}</p>
      <p><strong>Quantity:</strong> {product.Quantity}</p>
      <p><strong>Price:</strong> ${product.Price.toFixed(2)}</p>
    </div>
  );
}