import { Link } from 'react-router-dom'

export default function About() {
  return (
    <div>
      <h1>About Page</h1>
      <p>Welcome to the Product Management System</p>
      <Link to="/products">View Products</Link>
    </div>
  )
}