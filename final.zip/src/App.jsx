import { ProductProvider } from './context/ProductContext'; // Exact path
import { Routes, Route, Link } from 'react-router-dom';
import About from './pages/About';
import Products from './pages/Products';
import AddProduct from './pages/AddProduct';
import ProductDetail from './pages/ProductDetail';

export default function App() {
  return (
    <ProductProvider>
      <div>
        <nav>
          <Link to="/">About</Link> | 
          <Link to="/products">Products</Link>
        </nav>
        
        <Routes>
          <Route path="/" element={<About />} />
          <Route path="/products" element={<Products />} />
          <Route path="/products/add" element={<AddProduct />} />
          <Route path="/products/:id" element={<ProductDetail />} />
        </Routes>
      </div>
    </ProductProvider>
  );
}