import { useState, useEffect } from 'react';
import axios from 'axios';

export default function Products() {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:3000/products') // match JSON server port from screenshot
      .then(response => setProducts(response.data))
      .catch(error => console.error('Error:', error));
  }, []);

  return (
    <div>
      <h2>Products List</h2>
      <table border="1">
        <thead>
          <tr>
            <th>ID</th>
            <th>Product Name</th>
            <th>Quantity</th>
            <th>Price</th>
          </tr>
        </thead>
        <tbody>
          {products.map(product => (
            <tr key={product.id}>
              <td>{product.id}</td>
              <td>{product.ProductName}</td>
              <td>{product.Quantity}</td>
              <td>Rs. {product.Price}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
