export default function About() {
    return (
      <div className="page">
        <h1>About Page</h1>
        <p>This is the about page content</p>
      </div>
    );
  }