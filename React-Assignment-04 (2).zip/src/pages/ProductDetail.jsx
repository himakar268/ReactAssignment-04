import { useState, useEffect } from 'react'
import { useParams } from 'react-router-dom'
import { fetchProduct } from '../utils/api'

export default function ProductDetail() {
  const { id } = useParams()
  const [product, setProduct] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchProduct(id)
      .then(res => {
        setProduct(res.data)
        setLoading(false)
      })
      .catch(err => {
        console.error(err)
        setLoading(false)
      })
  }, [id])

  if (loading) return <div>Loading...</div>
  if (!product) return <div>Product not found</div>

  return (
    <div>
      <h1>Product Details</h1>
      <p><strong>ID:</strong> {product.id}</p>
      <p><strong>Name:</strong> {product.ProductName}</p>
      <p><strong>Quantity:</strong> {product.Quantity}</p>
      <p><strong>Price:</strong> {product.Price}</p>
    </div>
  )
}