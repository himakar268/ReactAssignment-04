import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { addProduct } from '../utils/api'

export default function AddProduct() {
  const [formData, setFormData] = useState({
    ProductName: '',
    Quantity: '',
    Price: ''
  })

  const [errors, setErrors] = useState({})
  const navigate = useNavigate()

  const validate = () => {
    const newErrors = {}
    if (!formData.ProductName.trim()) newErrors.ProductName = 'Required'
    if (!formData.Quantity) newErrors.Quantity = 'Required'
    if (!formData.Price) newErrors.Price = 'Required'
    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!validate()) return

    try {
      await addProduct(formData)
      navigate('/products')
    } catch (err) {
      console.error(err)
    }
  }

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    })
    setErrors({ ...errors, [e.target.name]: '' })
  }

  return (
    <div>
      <h1>Add Product</h1>
      <form onSubmit={handleSubmit}>
        <div style={{ marginBottom: '10px' }}>
          <input
            name="ProductName"
            value={formData.ProductName}
            onChange={handleChange}
            placeholder="Enter Product Name"
          />
          {errors.ProductName && (
            <span style={{ color: 'red', marginLeft: '10px' }}>{errors.ProductName}</span>
          )}
        </div>

        <div style={{ marginBottom: '10px' }}>
          <input
            name="Quantity"
            type="number"
            value={formData.Quantity}
            onChange={handleChange}
            placeholder="Enter Quantity"
            min="1"
          />
          {errors.Quantity && (
            <span style={{ color: 'red', marginLeft: '10px' }}>{errors.Quantity}</span>
          )}
        </div>

        <div style={{ marginBottom: '10px' }}>
          <input
            name="Price"
            type="number"
            step="0.01"
            value={formData.Price}
            onChange={handleChange}
            placeholder="Enter Price"
            min="0.01"
          />
          {errors.Price && (
            <span style={{ color: 'red', marginLeft: '10px' }}>{errors.Price}</span>
          )}
        </div>

        <button type="submit">Add Product</button>
      </form>
    </div>

  )
}
