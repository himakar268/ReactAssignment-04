export default function About() {
    return (
      <div>
        <h1>About Page</h1>
        <p><b>About:This application provides information about the products</b></p>    
      </div>
    )
  }