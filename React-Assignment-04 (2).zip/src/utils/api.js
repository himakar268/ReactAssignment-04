import axios from 'axios'

const API_URL = 'http://localhost:3000/products'

export const fetchProducts = () => axios.get(API_URL)
export const fetchProduct = (id) => axios.get(`${API_URL}/${id}`)
export const addProduct = (product) => axios.post(API_URL, product)